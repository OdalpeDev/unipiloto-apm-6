import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InfoTeacherPage } from './info-teacher';

@NgModule({
  declarations: [
    InfoTeacherPage,
  ],
  imports: [
    IonicPageModule.forChild(InfoTeacherPage),
  ],
})
export class InfoTeacherPageModule {}
