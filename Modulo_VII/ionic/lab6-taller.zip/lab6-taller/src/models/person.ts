export class Person {
    id: number;
    age: number;
    name: string;
    lastname: string;
  
    constructor(id: number, age: number, name: string, lastname: string) {
      this.id = id;
      this.age = age;
      this.name = name;
      this.lastname = lastname;
    }
  
  }